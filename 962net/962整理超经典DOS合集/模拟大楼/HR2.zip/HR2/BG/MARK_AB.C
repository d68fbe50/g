//*********************************************
//     BLOOD GROUP for HR2 THE SIMULATOR
//
//  NAME     :  FULL COLOR ERG USER type AB
//  PURPOSE  :  get ERG->build ORDER
//              FAIL->go G_PYLON
//  CHARACTER:  Nebaru
//
//  WRITER   :  ARTDINK 1994/12/16
//*********************************************


main()
{
	int	echk ;
	int	ans ;
	int	p ;
	int	h ;
	int	o ;
	int	c ;
	int	e ;

	c = favorite() ;
	echk = buggage() ;
	if( c != echk ){
		round( LEFT ) ;
		put() ;
		echk = FAIL ;
	}

	if( echk == FAIL ){
		ans = find( ERG ) ;
		if( ans != FAIL ){
			p = place() ;
			h = high() ;
			do{
				ans = go( p,h ) ;
			}while( ans == CONT ) ;
			e = get() ;
			do{
				ans = seek( R_FLAG ) ;
			}while( ans != SUCCESS ) ;
			move_mark() ;
		}
	}
	else{
		o = -1 ;
		if( echk == YELLOW )		o = STAIR ;
		else if( echk == BLUE )		o = FLOOR ;
		else if( echk == L_GRAY )	o = WINDOW ;
		else if( echk == D_GRAY )	o = PILAR ;
		else if( echk == WHITE )	o = WALL ;
		if( o != -1 ){
			ans = find( o ) ;
			if( ans == FAIL && o == WINDOW ){
				ans = find( GATE ) ;
			}
			if( ans == SUCCESS ){
				p = place() ;
				h = high() ;
				do{
					ans = go( p,h ) ;
				}while( ans == CONT ) ;
				if( ans == SUCCESS )	put() ;
			}
			do{
				ans = seek( R_FLAG ) ;
			}while( ans != SUCCESS ) ;
			move_mark() ;
		}
	}
	return( ans ) ;
}

move_mark()
{
	int	ans ;
	int	item ;

	do{
		ans = move() ;
		if( ans == FAIL ){
			item = code( FRONT ) ;
			if( item == G_FLAG ){
				break ;
			}
			else{
				round( RIGHT ) ;
			}
		}
	}while( 1 ) ;
}


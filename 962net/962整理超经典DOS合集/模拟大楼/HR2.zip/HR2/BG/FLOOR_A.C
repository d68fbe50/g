//*********************************************
//     BLOOD GROUP for HR2 THE SIMULATOR
//
//  NAME     :  FLOOR MAKER type A
//  PURPOSE  :  get ERG->build FLOOR
//  CHARACTER:  Majime
//
//  WRITER   :  ARTDINK 1994/12/16
//*********************************************

main()
{
	int	echk ;
	int	ans ;

	echk = buggage() ;
	if( echk == FAIL ){
		ans = get_erg() ;
	}
	else{
		ans = put_erg() ;
	}
	if( ans == FAIL ){
		if( echk == FAIL ){
			error_act( LEFT,LEFT ) ;
		}
		else{
			error_act( RIGHT,RIGHT ) ;
		}
	}
	return( ans ) ;
}

lets_go( int target )
{
	int	ans ;
	int	p ;
	int	h ;

	ans = find( target ) ;
	if( ans != FAIL ){
		p = place() ;
		h = high() ;
		do{
			ans = go( p,h ) ;
		}while( ans == CONT ) ;
	}
	return( ans ) ;
}

get_erg()
{
	int	ans ;

	ans = lets_go( ERG ) ;
	if( ans == SUCCESS ){
		ans = get() ;
	}
	return( ans ) ;
}

put_erg()
{
	int	ans ;

	ans = lets_go( FLOOR ) ;
	if( ans == SUCCESS ){
		ans = put() ;
	}
	return( ans ) ;
}

error_act( int dir1,int dir2 )
{
	int	i ;
	int	chk ;
	int	dir ;
	for( i=0 ; i<4 ; i++ ){
		chk = i%2 ;
		dir = dir1 ;
		if( chk != 0 )	dir = dir2 ;
		round( dir ) ;
	}
}


